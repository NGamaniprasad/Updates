package com.jlcindia.spring.entity; 
import java.math.BigDecimal; 
import javax.persistence.*; 

@Entity 
@Table(name="mybooks") 
public class Book { 
@Id 
@Column(name="bid") 
@GeneratedValue(strategy = GenerationType.AUTO) 
private Integer bid; 
@Column(name="bname") 
private String bname; 
@Column(name="author") 
private String author; 
@Column(name="price") 
private BigDecimal price; 
@Column(name="category") 
private String category; 
@Column(name="pub") 
private String pub; 
 
//Constructors 
//Setters and Getters 
@Override 
public String toString() { 
return "[" + bid + " , " + bname + " , " + author + " , " + price + " , " + category + " , " + pub+ "]";
} 
}