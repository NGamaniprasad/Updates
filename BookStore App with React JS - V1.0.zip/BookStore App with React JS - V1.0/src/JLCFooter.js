import React from "react"; 
 
const JLCFooter = () => { 
  return ( 
    <div> 
      <br />      <br />      <br /> 
      <footer className="bg-dark mytext-center mytext-large"> 
        <span className="mytext-large mywhite">&copy; 2020 JLCBookStore</span>{" "} 
        <br /> 
      </footer> 
    </div> 
  ); 
}; 
export default JLCFooter;