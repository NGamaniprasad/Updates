package com.coursecube.hibernate; 
 
import java.util.*; 
 
import org.hibernate.*; 
public class Lab20E { 
public static void main(String[] args) { 
Transaction tx=null; 
try { 
SessionFactory sf=HibernateUtil.getSessionFactory(); 
Session session=sf.openSession(); 
tx=session.beginTransaction(); 
 
//1. load Customer 
GoldCustomer cust=session.load(GoldCustomer.class, 2); 
 
Set<CreditCard> ccs=cust.getMycards(); 
//Deduct the Amount from Existing Card 
//Restul Web Services (Micro Service Architecture) 
 
Book book=session.load(Book.class, 3); 
OrderItem item=new OrderItem(1, 100, "OK OK",book); 
session.save(item); 
 
// 4. add Order and  associate 
Order order=new Order(new Date(),1,100,new 
Date(),"New"); 
session.save(order); 
 
order.setCustomer(cust); 
 
item.setOrder(order); 
 
// 5.add ShippingAddress and associate 
ShippingAddress add=new ShippingAddress("BTM 
2","Blore","KA",560076); 
session.save(add); 
order.setMyaddress(add); 
 
tx.commit(); 
session.close(); 
 
}catch(Exception ex) { 
ex.printStackTrace(); 
if(tx!=null) 
tx.rollback(); 
} 
} 
} 