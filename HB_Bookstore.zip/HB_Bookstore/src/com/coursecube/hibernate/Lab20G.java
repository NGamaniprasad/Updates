package com.coursecube.hibernate; 
 
import java.util.*; 
import org.hibernate.*; 
/* 
* @Author : Srinivas Dande 
* @company : CourseCube 
* @see           : www.coursecube.com 
* */ 
public class Lab20G { 
public static void main(String[] args) { 
Transaction tx=null; 
try { 
SessionFactory sf=HibernateUtil.getSessionFactory(); 
Session session=sf.openSession(); 
tx=session.beginTransaction(); 
 
Author author=session.load(Author.class,1); 
System.out.println(author); 
 
Set<Book> books=author.getMybooks(); 
 
for(Book book:books) 
System.out.println(book); 
 
tx.commit(); 
session.close(); 
 
}catch(Exception ex) { 
ex.printStackTrace(); 
if(tx!=null) 
tx.rollback(); 
} 
} 
}