package com.coursecube.hibernate; 
 
import java.util.*; 
import org.hibernate.*; 
 
public class Lab20B { 
public static void main(String[] args) { 
Transaction tx=null; 
try { 
SessionFactory sf=HibernateUtil.getSessionFactory(); 
Session session=sf.openSession(); 
tx=session.beginTransaction(); 
 
SilverCustomer sc=new SilverCustomer("hello", 
"hello@jlc.com", 111, new Date(), "bs@bs.com", 10, 10, 
10); 
session.save(sc); 
 
GoldCustomer gc=new GoldCustomer("hai", 
"hai@jlc.com", 222, new Date(), 99999, 1000, 50, true); 
session.save(gc); 
 
tx.commit(); 
session.close(); 
}catch(Exception ex) { 
ex.printStackTrace(); 
if(tx!=null) 
tx.rollback(); 
} 
} 
}