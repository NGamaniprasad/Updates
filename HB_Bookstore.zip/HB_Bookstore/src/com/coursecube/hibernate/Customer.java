package com.coursecube.hibernate; 
 
import java.util.Date; 
import java.util.Set; 
import javax.persistence.*; 
@Entity 
@Table(name="mycustomers") 
@Inheritance(strategy = InheritanceType.JOINED) 
public abstract class Customer { 
@Id 
@GeneratedValue(strategy = GenerationType.IDENTITY) 
@Column(name="cid") 
private int cid; 
 
@Column(name="cname") 
private String cname; 
 
@Column(name="email") 
private String email; 
 
@Column(name="phone") 
private long phone; 
 
@Column(name="dob") 
private Date dob; 
 
@OneToMany(mappedBy = "customer") 
private Set<CreditCard> mycards; 
 
@OneToMany(mappedBy = "customer") 
private Set<Order> myorders; 
 
public Customer() { } 
public Customer(String cname, String email, long phone, 
Date dob) { 
this.cname = cname;     this.email = email; 
this.phone = phone;    this.dob = dob; 
} 
//Setters and Getters 
@Override 
public String toString() { 
return cid + "\t" + cname + "\t" + email + "\t" +  phone + 
"\t" +  dob ; 
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getPhone() {
	return phone;
}
public void setPhone(long phone) {
	this.phone = phone;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Set<CreditCard> getMycards() {
	return mycards;
}
public void setMycards(Set<CreditCard> mycards) {
	this.mycards = mycards;
}
public Set<Order> getMyorders() {
	return myorders;
}
public void setMyorders(Set<Order> myorders) {
	this.myorders = myorders;
}    } 