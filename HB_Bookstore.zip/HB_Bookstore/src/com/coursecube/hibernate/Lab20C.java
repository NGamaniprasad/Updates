package com.coursecube.hibernate; 
 
import java.util.*; 
 
import org.hibernate.*; 
 
public class Lab20C { 
public static void main(String[] args) { 
Transaction tx=null; 
try { 
SessionFactory sf=HibernateUtil.getSessionFactory(); 
Session session=sf.openSession(); 
tx=session.beginTransaction(); 
 
//1. load Customer 
SilverCustomer cust=session.load(SilverCustomer.class, 
1); 
//2. add CreditCard and associate 
CreditCard cc=new CreditCard(12345, "VISA", new 
Date(), 999, "Active"); 
session.save(cc); 
//Deduct the Amount from New Card 
cc.setCustomer(cust); 
 
//3.add OrderItems and associate 
Book book1=session.load(Book.class, 1); 
OrderItem item1=new OrderItem(2, 200, "OK",book1); 
session.save(item1); 
 
Book book2=session.load(Book.class, 2); 
OrderItem item2=new OrderItem(3, 200, "OK",book2); 
session.save(item2); 
 
Book book3=session.load(Book.class, 3); 
OrderItem item3=new OrderItem(5, 200, "OK",book3); 
session.save(item3); 
 
// 4. add Order and  associate 
Order order=new Order(new Date(),10,700,new 
Date(),"New"); 
session.save(order); 
 
order.setCustomer(cust); 
 
item1.setOrder(order); 
item2.setOrder(order); 
item3.setOrder(order); 
 
// 5.add ShippingAddress and associate 
ShippingAddress add=new 
ShippingAddress("BTM","Blore","KA",560076); 
session.save(add); 
order.setMyaddress(add); 
 
tx.commit(); 
session.close(); 
 
}catch(Exception ex) { 
ex.printStackTrace(); 
if(tx!=null) 
tx.rollback(); 
} 
 
} 
}