package com.coursecube.hibernate; 
 
import javax.persistence.*; 
@Entity 
@Table(name="orderItems") 
public class OrderItem { 
@Id 
@GeneratedValue(strategy = 
GenerationType.IDENTITY) 
@Column(name="orderItemId") 
private int orderItemId; 
 
@Column(name="qty") 
private int qty; 
 
@Column(name="cost") 
private double cost; 
 
@Column(name="status") 
private String status; 
 
@ManyToOne 
@JoinColumn(name="myOrderId",referencedColumnN
 ame = "orderId") 
private Order order; 
 
@ManyToOne 
@JoinColumn(name="myBookId",referencedColumnNa
 me = "bookId") 
private Book mybook; 
 
public OrderItem() {} 
public OrderItem(int qty, double cost, String status) { 
this.qty = qty;    this.cost = cost; 
this.status = status; 
} 
public OrderItem(int qty, double cost, String status, 
Book mybook) { 
this.qty = qty; 
this.cost = cost; 
this.status = status; 
this.mybook = mybook; 
} 
//Setters and Getters 
//toString() 
}