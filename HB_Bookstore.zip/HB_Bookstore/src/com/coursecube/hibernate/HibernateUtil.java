package com.coursecube.hibernate; 
 
public class HibernateUtil { 
 static SessionFactory  sessionFactory; 
static { 
Configuration cfg=new Configuration(); 
 
Properties props=new Properties(); 
props.put(Environment.DRIVER, 
"com.mysql.jdbc.Driver"); 
props.put(Environment.URL, 
"jdbc:mysql://localhost:3306/bstoredb"); 
props.put(Environment.USER, "root"); 
props.put(Environment.PASS, "Gamani"); 
 
props.put(Environment.SHOW_SQL, "true"); 
props.put(Environment.DIALECT, 
"org.hibernate.dialect.MySQLDialect"); 
 
props.put(Environment.CURRENT_SESSION_CONTEXT_C
 LASS, "thread"); 
props.put(Environment.HBM2DDL_AUTO, "update"); 
 
cfg.setProperties(props); 
 
cfg.addAnnotatedClass(Customer.class); 
cfg.addAnnotatedClass(SilverCustomer.class); 
cfg.addAnnotatedClass(GoldCustomer.class); 
cfg.addAnnotatedClass(ShippingAddress.class); 
cfg.addAnnotatedClass(CreditCard.class); 
cfg.addAnnotatedClass(Order.class); 
cfg.addAnnotatedClass(OrderItem.class); 
cfg.addAnnotatedClass(Book.class); 
cfg.addAnnotatedClass(Author.class); 
 
StandardServiceRegistryBuilder ssrbuilder=new 
StandardServiceRegistryBuilder(); 
ServiceRegistry 
serviceReg=ssrbuilder.applySettings(cfg.getProperties()).
 build(); 
sessionFactory=cfg.buildSessionFactory(serviceReg); 
} 
public static SessionFactory getSessionFactory() { 
return sessionFactory; 
} 
}