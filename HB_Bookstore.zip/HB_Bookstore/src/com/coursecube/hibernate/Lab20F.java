package com.coursecube.hibernate; 
 
import java.util.*; 
import org.hibernate.*; 
 
public class Lab20F { 
public static void main(String[] args) { 
Transaction tx=null; 
try { 
SessionFactory sf=HibernateUtil.getSessionFactory(); 
Session session=sf.openSession(); 
tx=session.beginTransaction(); 
 
// GoldCustomer cust=session.load(GoldCustomer.class, 
2); 
SilverCustomer cust=session.load(SilverCustomer.class, 
1); 
System.out.println(cust); 
 
Set<CreditCard> cards=cust.getMycards(); 
for(CreditCard cc:cards) 
System.out.println(cc); 
 
Set<Order> orders= cust.getMyorders(); 
for(Order order:orders) { 
System.out.println(order); 
ShippingAddress add=order.getMyaddress(); 
System.out.println(add); 
Set<OrderItem> items=order.getMyOrderItems(); 
for(OrderItem oitem:items) { 
System.out.println(oitem); 
System.out.println(oitem.getMybook()); 
} 
} 
 
tx.commit(); 
session.close(); 
}catch(Exception ex) { 
ex.printStackTrace(); 
if(tx!=null) 
tx.rollback(); 
} 
} 
}