package com.coursecube.hibernate; 
 
import java.util.*; 
import org.hibernate.*; 
/* 
* @Author : Srinivas Dande 
* @company : CourseCube 
* @see           : www.coursecube.com 
* */ 
public class Lab20D { 
public static void main(String[] args) { 
Transaction tx=null; 
try { 
SessionFactory sf=HibernateUtil.getSessionFactory(); 
Session session=sf.openSession(); 
tx=session.beginTransaction(); 
 
//1. load Customer 
GoldCustomer cust=session.load(GoldCustomer.class, 
2); 
 
//2. add CreditCard and associate 
CreditCard cc=new CreditCard(55555, "MASTER", new 
Date(), 555, "Active"); 
session.save(cc); 
 
cc.setCustomer(cust); 
 
tx.commit(); 
session.close(); 
}catch(Exception ex) { 
ex.printStackTrace(); 
if(tx!=null) 
tx.rollback(); 
} 
} 
}