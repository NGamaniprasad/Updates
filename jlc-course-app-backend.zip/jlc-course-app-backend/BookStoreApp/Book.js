const mongoose = require("mongoose"); 
const Schema = mongoose.Schema; 
 
let BookSchema = new Schema( 
  {  
  bookId: Number, 
  bookName: String, 
  author: String, 
  category: String, 
  publications: String, 
  price: String, 
  }, 
  {   
  timestamps: true, 
  collection: 'mybooks' 
 } 
); 
 
const Book = mongoose.model('Book', BookSchema); 
module.exports = Book; 