const express = require("express"); 
const dotenv = require("dotenv"); 
const bodyParser = require('body-parser'); 
const mongoose = require('mongoose'); 
const path = require('path'); 
const cors = require("cors"); 
 
const BookController = require('./src/mycontrollers/BookController'); 
 
dotenv.config({ path: ".env.jlc" }); 
 
const app = express(); 
const PORT = process.env.PORT || 5500; 
 
 mongoose.connect(process.env.MONGODB_URI, { 
    useUnifiedTopology: true, 
 
  
    useFindAndModify: false, 
    useNewUrlParser: true, 
  }).then(() => { 
    console.log('MongoDB connected successfully.'); 
  }, error => { 
    console.error(error); 
    console.log('MongoDB connection error. Please make sure MongoDB is running.'); 
    process.exit(); 
  }); 
   
  /** 
   * Add middlewares 
   */ 
  app.use(bodyParser.json()); 
  app.use(bodyParser.urlencoded({ 
    extended: false 
  })); 
   
  app.use(cors()); 
 
app.get("/hello", (req, res) => { 
  console.log("Request for - /hello"); 
   return res.send("Hello Guys -- I am Ready"); 
}); 
 
app.get('/myapi/mybooks', BookController.getAllBooks); 
app.get('/myapi/mybooks/:bookId', BookController.findBookByBookId); 
app.get('/myapi/maxId', BookController.findMaxBookId); 
app.post('/myapi/mybooks', BookController.addBook); 
app.put('/myapi/mybooks', BookController.updateBook); 
app.delete('/myapi/mybooks/:bookId', BookController.deleteBook); 
app.get('/myapi/mybooks/category/:category', BookController.findBooksByCategory); 
app.get('/myapi/mybooks/category/:category/price/:price', 
BookController.findBooksByCatAndPrice); 
 
/** 
 * start Express server on port 5500 
 */ 
app.listen(PORT, () => { 
  console.log("Express server is running at http://localhost:%d", PORT); 
  console.log("Press CTRL-C to stop\n"); 
});