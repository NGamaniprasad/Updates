let Book = require("../mymodels/Book"); 
 
// Get All Books 
exports.getAllBooks = (req, res, next) => { 
    console.log("/mybooks ---get()"); 
    Book.find((error, data) => { 
        if (error) { 
            return next(error); 
        } else { 
            res.json(data); 
        } 
    }).sort({ 
        bookId: 1 
    }); 
}; 
 
// Get Book By Book Id 
exports.findBookByBookId = (req, res, next) => { 
    console.log("/mybook --- get()"); 
    Book.findOne({ 
        bookId: parseInt(req.params.bookId) 
    }, (error, data) => { 
        if (error) { 
            return next(error); 
        } else { 
            console.log(data) 
            res.json(data); 
        } 
    }); 
}; 
 
// Get Book with maximum Book Id 
exports.findMaxBookId = (req, res, next) => { 
    console.log("/myapi/maxId --- get()"); 
    Book.find({}, (error, data) => { 
        if (error) { 
            return next(error); 
        } else { 
            res.json(data); 
        } 
    }) .sort({  bookId: -1 }).limit(1); 
}; 
 
 
exports.addBook = (req, res) => { 
    console.log("/addBook- post-"); 
    console.log(req.body); 
    console.log("BookId : " + req.body.bookId); 
    console.log("bookName : " + req.body.bookName); 
    console.log("author : " + req.body.author); 
    console.log("price : " + req.body.price); 
    console.log("category : " + req.body.category); 
    console.log("pub : " + req.body.publications); 
 
    Book.create(req.body, (error, data) => { 
        if (error) { 
            return next(error); 
        } else { 
            res.json(data); 
            console.log("Book added successfully"); 
        } 
    }); 
}; 
 
// Update Book 
exports.updateBook = (req, res, next) => { 
    console.log("/updateBook - put()"); 
    console.log(req.body.bookId); 
    console.log(req.body); 
    Book.findOneAndUpdate({ 
        bookId: req.body.bookId 
    }, 
        req.body, 
        (error, data) => { 
            if (error) { 
                return next(error); 
            } else { 
                res.json(data); 
                console.log("Book updated successfully"); 
            } 
        } 
    ); 
}; 
 
 
// Delete Book 
exports.deleteBook = (req, res, next) => { 
    console.log("/deleteBook - delete()"); 
    console.log(req.params.bookId); 
 
    Book.findOneAndRemove({ 
        bookId: parseInt(req.params.bookId) 
    }, 
        (error, data) => { 
            if (error) { 
                return next(error); 
            } else { 
                res.json(data); 
                console.log("Book Deleted successfully"); 
            } 
        } 
    ); 
}; 
 
// Get Books By Category 
exports.findBooksByCategory = (req, res, next) => { 
    console.log("/mybooks/category/:/ --- get()");    
     Book.find( 
    { 
        category: req.params.category 
    },  
    (error, data) => { 
        if (error) { 
            return next(error); 
        } else { 
            console.log(data) 
            res.json(data); 
        } 
    } 
).sort({ 
        bookId: 1 
    });   
 
};  
// Get Books By Category and Price 
exports.findBooksByCatAndPrice = (req, res, next) => { 
    console.log("/mybooks/category/:/price/: --- get()"); 
    Book.find( 
    { 
        category: req.params.category, 
        price:parseInt(req.params.price) 
    },  
    (error, data) => { 
        if (error) { 
            return next(error); 
        } else { 
            console.log(data) 
            res.json(data); 
        } 
    } 
).sort({ 
        bookId: 1 
    });   
 
};