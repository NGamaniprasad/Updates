import React from 'react'

const Footer = () => {
  return (
    <div className='footerSection'>
       <div className="bannerBox">
        <img src="assets/footer.png" alt="banner" />
      </div>
    </div>
  )
}

export default Footer