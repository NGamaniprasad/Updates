const express = require('express'); 
const dotenv = require('dotenv'); 
 
const bodyParser = require('body-parser'); 
const mongoose = require('mongoose'); 
const path = require('path'); 
const cors = require("cors"); 
 
const BookController = require('./src/controllers/BookController'); 
 
dotenv.config({     path: '.env.jlc'  }); 
const app = express(); 
const PORT = process.env.PORT || 5500; 
/** 
* Connect to MongoDB. 
*/ 
mongoose.connect(process.env.MONGODB_URI, { 
useUnifiedTopology: true, 
useFindAndModify: false, 
useNewUrlParser: true, 
}).then(() => { 
console.log('MongoDB connected successfully.'); 
}, error => { 
console.error(error); 
console.log('MongoDB connection error. Please make sure MongoDB is running.'); 
process.exit(); 
}); 
/** 
* Add middlewares 
*/ 
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ 
extended: false 
})); 
app.use(cors()); 
app.get('/hello', (req, res) => { 
return res.send('Hello Guys') 
}) 
app.get('/myapi/mybooks', BookController.getAllBooks); 
app.get('/myapi/mybooks/:bookId', BookController.findBookByBookId); 
// Start Server on port 5500 
app.listen(PORT, () => { 
console.log('Server is running at http://localhost:%d', PORT); 
console.log('Press CTRL-C to stop\n'); 
});