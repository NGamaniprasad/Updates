
document.addEventListener("DOMContentLoaded", function() {
    if (!localStorage.getItem("cookieConsent")) {
        document.getElementById("cookie-consent").style.display = "flex";
    }

    document.getElementById("accept-cookies").addEventListener("click", function() {
        localStorage.setItem("cookieConsent", "accepted");
        document.getElementById("cookie-consent").style.display = "none";
    });
});
